import os

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///seniorsaledatabase.db")


@app.route("/")
@login_required
def landing():
    return render_template("landing.html")

@app.route("/check", methods=["GET"])
def check():
    """Return true if username available, else false, in JSON format"""

    # Get username
    username = request.args.get("username")

    # Check for username
    if not len(username) or db.execute("SELECT 1 FROM users WHERE username = :username", username=username.lower()):
        return jsonify(False)
    else:
        return jsonify(True)


@app.route("/browse")
@login_required
def browse():
    """Shows a list of items for sale by all users on the website."""
    items_list = db.execute("SELECT * FROM itemslist")
    return render_template("browse.html", items_list=items_list)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in."""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out."""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/login")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Creates an account for a new user."""

    # POST
    if request.method == "POST":

        # Validate form submission
        if not request.form.get("username"):
            return apology("Enter a username!")
        elif not request.form.get("password"):
            return apology("Enter a password!")
        elif request.form.get("password") != request.form.get("confirmation"):
            return apology("Your password confirmation does not match your password!")

        # Add user to database
        id = db.execute("INSERT INTO users (username, hash) VALUES(:username, :hash)",
                        username=request.form.get("username"),
                        hash=generate_password_hash(request.form.get("password")))
        if not id:
            return apology("Someone else already has this username.")

        # Log user in
        session["user_id"] = id

        # Let user know they're registered
        flash("Your username and password are now registered!")
        return redirect("/")

    # GET
    else:
        return render_template("register.html")


@app.route("/post", methods=["GET", "POST"])
@login_required
def post():
    """Enables user to post a new item for sale."""

    #GET
    if request.method == "GET":
        return render_template("post.html")

    # POST
    if request.method == "POST":
        # Allows users to post a new item for sale!
        db.execute("INSERT INTO itemslist (item_name, price, description, user_id, contactinfo) VALUES (:item_name, :price, :description, :user_id, :contactinfo)",
                        item_name=request.form.get("item_name"),
                        price=request.form.get("price"),
                        description=request.form.get("description"),
                        user_id=session["user_id"],
                        contactinfo=request.form.get("contactinfo"))

        return redirect("/browse")

    # Otherwise
    else:
        return apology("Hmmm... something went wrong.")


@app.route("/unpost", methods=["GET", "POST"])
@login_required
def unpost():
    """Enables user to remove an item from the sale list."""
    items_list = db.execute("SELECT * FROM itemslist WHERE (user_id = :user_id)", user_id=session["user_id"])

    #GET
    if request.method == "GET":
        return render_template("unpost.html", items_list=items_list)

    # POST
    if request.method == "POST":
        # TODO - allows users to remove an item from the sale list!
        # Ensures that the user can only sell items that they posted
        db.execute("DELETE FROM itemslist WHERE (item_name = :item_name)", item_name=request.form.get("item_name"))
        return redirect("/browse")

    # Otherwise
    else:
        return apology("Hmmm... something went wrong.")


def errorhandler(e):
    """Handle error"""
    return apology(e.name, e.code)


# listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
