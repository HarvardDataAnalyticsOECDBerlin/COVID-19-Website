# User Manual for the Harvard Yard Sale Website - CS50 Final Project

## Starting up the website:
Begin by downloading the files contained in the seniorsale" folder into CS50 IDE. Type "cd" into the terminal to return to your home directory, then enter "cd seniorsale" to change your working directory to the "seniorsale" folder. Once you are in the "seniorsale" folder, type "flask run" in the terminal to launch the website and click the link that is provided in the terminal to reach the website. You should see this link as the fourth bullet point and it is likely to start with the text "* Running on https://" Upon clicking this link, you will be taken to the website and can begin using it.

## Registering yourself as a new user:
Once you open the website, you should find yourself on a login page that allows returning users to sign into their accounts. Since you do not yet have an account, please click the Register button in the upper right hand corner of the webpage. Now, enter a username and password in the spaces provided, then enter the same password again to confirm it. Once you have entered your username and password, click the "Register" button below the input spaces. You should receive an alert that you have now registered yourself as a new user and you can proceed to other parts of the website. You will be automatically logged into your account.

## Browsing for items/Viewing Items Posted for Sale:
Click the "Browse for items" in the header at the top of the screen to view items that all users have posted to the website. For each item, you will see the name of the item, its price, a brief description, and the contact information for the person selling that item. Browse through this list at your leisure and the contact information is there to negotiate a transaction with any seller if you decide to purchase an item.

## Posting an item:
If you would like to post a new item, click the "Post an item for sale" in the header at the top of the webpage. Enter the item's name, price, a brief description, and the contact information that you wish to use to negotiate this sale in the input places provided. Once all input fields have been completed, click the "Post a new item" button. You will now be taken to the page where you can browse for items, so you can view your item's posting. Now await someone to contact you for your sale!

## Removing an item from the sale list:
If you are contacted by a buyer and you sell your item or if you decide that your item is no longer for sale, then you may wish to remove an item from the list of items for sale. You can do this by clicking the "Remove an item" in the header at the top of the webpage. You can peruse the drop down menu for the item that you wish to remove. This list will show you only the items that you posted, so you cannot remove another user's item. To remove one of your postings from the list, select that item's name from the drop-down menu and click the "Remove item from sale list" button. You will now be redirected to the page in which you can browse items that are listed for sale and you will see that your item is now deleted from that list of items for sale.

## Once you are done with the website:
When you have finished using the website, be sure to click "Log Out" in the top right hand corner.


Thanks for using the Harvard Yard Sale Website!!!